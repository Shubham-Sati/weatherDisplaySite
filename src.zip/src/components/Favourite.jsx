import React from 'react'

const Favourite = () => {
  return (
    <div>Favourite</div>
  )
}

export default Favourite
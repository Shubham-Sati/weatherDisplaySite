import React from "react";

const WeatherPrediction = () => {
  return (
    <div
      style={{
        width: "300px",
        padding: "0 30px",
        backgroundColor: "greenyellow",
      }}
    >
      WeatherPrediction
    </div>
  );
};

export default WeatherPrediction;
